package ac.kr4.controller;

import ac.kr4.Repository.ProfileRepository;
import ac.kr4.domain.Profile;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class ProfileController {

    private ProfileRepository profileRepository;

    public ProfileController(ProfileRepository profileRepository) {
        this.profileRepository = profileRepository;
    }

    @GetMapping("/profile")
    public List<String>Profile(){
        List<String> profilelist = new ArrayList<>();

        for (Profile p : profileRepository.findAll()){
            profilelist.add(p.getNetwork());
        }
        return profilelist;
    }
}
