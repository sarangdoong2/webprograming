package ac.kr4.Repository;

import ac.kr4.domain.Location;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LocationRepository extends JpaRepository<Location, Long> {
    Location findByAddress(final String adress);
}
