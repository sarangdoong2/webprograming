package ac.kr4.controller;


import ac.kr4.Repository.BasicRepository;
import ac.kr4.domain.Basic;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class BasicController {

    private BasicRepository basicRepository;

    public BasicController(BasicRepository basicRepository) {this.basicRepository = basicRepository;}

    @GetMapping("/basic")   //localhost:8080해서 들어갔을 때
    public List<String> Basic(){
        List<String> basiclist = new ArrayList<>();

        for (Basic b : basicRepository.findAll()){
            basiclist.add(b.getName());
        }

        return basiclist;
    }
}
