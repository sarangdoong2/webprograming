package com.n2017848104.main.domain;


import com.n2017848104.main.repository.ProfileRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;
import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;

import java.time.LocalDateTime;

@RunWith(SpringRunner.class)
@DataJpaTest

public class ProfileTest {
    @Autowired
    private ProfileRepository profileRepository;
    private Profile savedProfile;

    @Before
    public void init(){
        savedProfile = profileRepository.save(Profile.builder()
                                        .network("트위터")
                                        .username("@hong")
                                        .url("https://twitter/@hong")
                                        .createdAt(LocalDateTime.now())
                                        .build());
    }

    @Test
    public void testFindIDProfile(){
        Profile foundProfile = profileRepository.findById(savedProfile.getIdx()).orElse(null);
        assertThat(foundProfile.getIdx()).isEqualTo(savedProfile.getIdx());
    }

    @Test
    public void testFindNameProfile(){
        Profile findNetworkProfile = profileRepository.findFirstByNetwork("트위터");
        assertThat(findNetworkProfile.getNetwork()).isEqualTo("트위터");
    }
}
