package com.n2017848104.main;

import com.n2017848104.main.domain.Basic;
import com.n2017848104.main.domain.Profile;
import com.n2017848104.main.repository.BasicRepository;
import com.n2017848104.main.repository.ProfileRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.time.LocalDateTime;
import java.util.stream.IntStream;

@SpringBootApplication
public class MainApplication {

	public static void main(String[] args) {
		SpringApplication.run(MainApplication.class, args);
	}

	@Bean
	public CommandLineRunner runner(BasicRepository basicRepository, ProfileRepository profileRepository) {
		return (args) -> {
			IntStream.rangeClosed(1, 7).forEach(index ->
				basicRepository.save(Basic.builder()
						.name("이름" + index)
						.label("직책" + index)
						.email("이메일" + index)
						.phone("연락처" + index)
						.build()));

			IntStream.rangeClosed(1, 7).forEach(index ->
				profileRepository.save(Profile.builder()
						.network("SNS" + index)
						.username("ID" + index)
						.url("링크" + index + "@naver.com")
						.createdAt(LocalDateTime.now())
						.build()));

		};
	}

}
