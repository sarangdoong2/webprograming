package ac.kr4.controller;

import ac.kr4.Repository.LocationRepository;
import ac.kr4.domain.Location;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class LocationController {

    private LocationRepository locationRepository;

    public LocationController(LocationRepository locationRepository) {
        this.locationRepository = locationRepository;
    }

    @GetMapping("/location")
    public List<String> Location() {
        List<String> locationlist = new ArrayList<>();

        for (Location l : locationRepository.findAll()) {
            locationlist.add(l.getAddress());
        }
        return locationlist;
    }
}