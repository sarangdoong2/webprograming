package ac.kr4.controller;

import ac.kr4.Repository.WorkRepository;
import ac.kr4.domain.Work;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class WorkController {
    private WorkRepository workRepository;

    public WorkController(WorkRepository workRepository) {
        this.workRepository = workRepository;
    }

    @GetMapping("/work")
    public List<String>Work(){
        List<String> worklist = new ArrayList<>();

        for (Work w : workRepository.findAll()){
            worklist.add(w.getCompany());
        }
        return worklist;
    }
}
