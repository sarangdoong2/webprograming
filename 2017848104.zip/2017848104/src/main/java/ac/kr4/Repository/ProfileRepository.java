package ac.kr4.Repository;

import ac.kr4.domain.Profile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProfileRepository extends JpaRepository<Profile, Long> {
    Profile findByNetwork(final String network);
}
